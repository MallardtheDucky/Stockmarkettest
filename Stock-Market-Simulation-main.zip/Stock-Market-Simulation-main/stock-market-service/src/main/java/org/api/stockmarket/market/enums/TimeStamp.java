package org.api.stockmarket.market.enums;

public enum TimeStamp {
    EndOfDay,
    MiddleOfDay,
    EndOfMonth
}
