package org.api.stocktradingservice.account.properties;

public class SchedulingProperties {

    public static final long EVERY_10_MINUTES = 10 * 60 * 1000;
}
