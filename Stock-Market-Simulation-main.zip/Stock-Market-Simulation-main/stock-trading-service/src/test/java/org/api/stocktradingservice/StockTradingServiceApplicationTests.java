package org.api.stocktradingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockTradingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
